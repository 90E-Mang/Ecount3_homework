﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyCafeManager
{
    class Admin : Person
    {
        public Admin()
        {
            this.name = "admin";
            this.email = "admin";
            this.pw = "0000";
        }
    }
}
